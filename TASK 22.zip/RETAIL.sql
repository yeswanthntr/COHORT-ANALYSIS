USE ONL;
WITH cleaned_data AS (

    SELECT
        `Customer ID`,
        `InvoiceDate`,
        `Invoice`
    FROM online
    WHERE `Customer ID` IS NOT NULL
      AND `Invoice` NOT LIKE 'C%'

),

purchase_months AS (

    SELECT
        `Customer ID`,
        DATE_FORMAT(`InvoiceDate`, '%Y-%m-01') AS PurchaseMonth
    FROM cleaned_data

),

customer_cohort AS (

    SELECT
        `Customer ID`,
        MIN(PurchaseMonth) AS CohortMonth
    FROM purchase_months
    GROUP BY `Customer ID`

),

customer_activity AS (

    SELECT DISTINCT
        p.`Customer ID`,
        p.PurchaseMonth,
        c.CohortMonth
    FROM purchase_months p
    JOIN customer_cohort c
        ON p.`Customer ID` = c.`Customer ID`

),

cohort_index AS (

    SELECT
        `Customer ID`,
        CohortMonth,
        PurchaseMonth,

        TIMESTAMPDIFF(
            MONTH,
            CohortMonth,
            PurchaseMonth
        ) AS CohortIndex

    FROM customer_activity

),

cohort_counts AS (

    SELECT
        CohortMonth,
        CohortIndex,
        COUNT(DISTINCT `Customer ID`) AS Customers
    FROM cohort_index
    GROUP BY
        CohortMonth,
        CohortIndex

)

SELECT
    CohortMonth,
    CohortIndex,
    Customers
FROM cohort_counts
ORDER BY
    CohortMonth,
    CohortIndex;